package com.example.lancelot.fullscreensnakegame;

public enum GameState {
    Ready,
    Running,
    Paused,
    Lost
}

package com.example.lancelot.fullscreensnakegame;

public enum TileType {
    Nothing,
    Wall,
    SnakeHead,
    SnakeTail,
    Apple
}

package com.example.lancelot.fullscreensnakegame;

public enum Direction {
    North,
    East,
    South,
    West
}
